# Camel

The camel package implements camel case word splitting.
