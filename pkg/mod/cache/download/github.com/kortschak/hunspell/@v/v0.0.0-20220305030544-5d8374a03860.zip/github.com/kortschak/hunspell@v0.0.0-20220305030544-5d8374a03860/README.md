# hunspell

The hunspell package provides bindings to the hunspell spelling library.
